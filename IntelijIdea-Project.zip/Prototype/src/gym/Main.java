package gym;

/**
 * Classe Main qui initialise le centre de données
 */
public class Main {

    public static void main(String[] args) {

	    DataCenter dataCenter = new DataCenter();

    }
}