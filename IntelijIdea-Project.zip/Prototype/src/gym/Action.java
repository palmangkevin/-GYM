package gym;

public interface Action {
	String getTitle();

	void launch();
}
